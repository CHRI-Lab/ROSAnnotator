import LoadingPage from './LoadingPage';
export default LoadingPage;