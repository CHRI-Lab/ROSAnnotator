import LoadableList from "./LoadableList";
export { LoadableList as LandingPage };
