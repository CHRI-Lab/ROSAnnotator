import Annotator from './Annotator';
export default Annotator;
