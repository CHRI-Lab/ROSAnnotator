import StatisticsAnnotation from "./StatisticsAnnotation";
export default StatisticsAnnotation;
