import StatisticsTier from "./StatisticsTier";
export default StatisticsTier;
