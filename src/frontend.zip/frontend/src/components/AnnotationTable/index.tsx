import AnnotationTable from './AnnotationTable';
export default AnnotationTable;
