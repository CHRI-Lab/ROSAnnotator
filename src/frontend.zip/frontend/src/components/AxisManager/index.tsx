import AxisManager from './AxisManager';
export default AxisManager;
