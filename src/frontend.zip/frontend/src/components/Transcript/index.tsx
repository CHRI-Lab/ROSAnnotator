import Transcript from './Transcript';
export default Transcript;
